#!/usr/bin/env python
# coding: utf-8

# # KNeighborsClassifier

# In[82]:


from sklearn.neighbors import KNeighborsClassifier
import os
import subprocess

import pandas as pd
import numpy as np
import graphviz
from sklearn.tree import export_graphviz

#Incarcare dataset
input_file = "data_banknote_authentication.txt"
data = pd.read_csv(input_file, header = 0)

array = data.values
X = array[:,0:4]
Y = array[:,4]
data


# In[83]:


#Primele 5 inregistrari
data.head()


# In[84]:


#Impartire dataset: train + test
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.30)
print(X_train.shape)
print(X_test.shape)


# In[85]:


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

print(X_train.shape)
print(X_test.shape)
X_test


# In[86]:


#Fit + Predict
model = KNeighborsClassifier()
model.fit(X_train, Y_train)
Y_prediction = model.predict(X_test)

print("Y: ",Y)
print("Y_prediction:",Y_prediction)
print("Y_test:",Y_test)


# In[101]:


#Testare estimator pe 2 exemple concrete
#prima inregistrare ar trebui sa aiba valoarea 0, a doua valoarea 1
my_test= [[3.6216,8.6661,-2.8073,-0.44699],[-2.5419,-0.65804,2.6842,1.1952]]
Y_prediction_test= model.predict(my_test)
print("Prediction form my given test:",Y_prediction_test)


# In[87]:


#5 metrici pentru clasificatorul initial
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score


print("Accuracy:",metrics.accuracy_score(Y_test, Y_prediction))

confusion_mat = confusion_matrix(Y_test, Y_prediction)
print("Confusion matrix is : ", confusion_mat)

recall_show = recall_score(Y_test, Y_prediction) 
print("Recall_score is :",recall_show)

precision_show = precision_score(Y_test, Y_prediction) 
print("Precision Score is : ", precision_show)

f1_score=f1_score(Y_test, Y_prediction)
print("f1 Score is : ",f1_score)


# In[88]:


#Cross-validation-evaluare scor
from sklearn.model_selection import cross_val_score
cross_val_score(model, X,Y,cv=5)  


# In[89]:


#GridSearch pentru imbunatatire rezultate-cautarea celor mai bune valori pentru parametri
from sklearn import datasets
from sklearn.model_selection import GridSearchCV
parameters = {'n_neighbors':range(5,17),'weights':('uniform', 'distance') ,'algorithm':('auto','ball_tree','kd_tree','brute')}
model2 = KNeighborsClassifier()
clf = GridSearchCV(model2, parameters)
clf.fit(X, Y)


# In[90]:


clf.best_params_


# In[91]:


from sklearn.metrics import f1_score
#Schimbare parametrii pentru a imbunatati performanta
#Valorile pentru parametrii sunt cei gasiti de GridSearch

clf.fit(X_train,Y_train)
Y_prediction = clf.predict(X_test)
print("Y: ",Y)
print("Y_prediction:",Y_prediction)
print("Y_test:",Y_test)
print("Metricile dupa setarea parametrilor optimi:")
print("Accuracy:",metrics.accuracy_score(Y_test, Y_prediction))

confusion_mat = confusion_matrix(Y_test, Y_prediction)
print("Confusion matrix is : ", confusion_mat)

recall_show = recall_score(Y_test, Y_prediction) 
print("Recall_score is :",recall_show)

precision_show = precision_score(Y_test, Y_prediction) 
print("Precision Score is : ", precision_show)

f1_score = f1_score(Y_test, Y_prediction)
print("f1 Score is : ",f1_score)


# In[92]:


#Cross-validation pentru modelul cu parametrii gasiti de GridSearch
from sklearn.model_selection import cross_val_score
cross_val_score(clf, X,Y,cv=2)


# # Vizualizare rezultate obtinute cu parametri diferiti

# In[93]:


#Vizualizare rezultate obtinute cu parametri diferiti
range_k = range(1,30)
scores = {}
scores_list = []

for k in range_k:
   classifier = KNeighborsClassifier(n_neighbors=k)
   classifier.fit(X_train, Y_train)
   Y_prediction = classifier.predict(X_test)
   scores[k] = metrics.accuracy_score(Y_test,Y_prediction)
   scores_list.append(metrics.accuracy_score(Y_test,Y_prediction))


# In[94]:


get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt

plt.plot(range_k,scores_list)
plt.xlabel("Number of neighbors")
plt.ylabel("Accuracy")


# In[95]:


classifier = KNeighborsClassifier(n_neighbors=10)
classifier.fit(X_train, Y_train)
Y_prediction = classifier.predict(X_test)
print(Y_prediction)
print(Y_test)

result = metrics.confusion_matrix(Y_test, Y_prediction)
print("Confusion Matrix:")
print(result)

result1 = metrics.classification_report(Y_test, Y_prediction)
print("Classification Report:",)
print (result1)


# # RadiusNeighborsClassifier

# In[96]:


#Incarcare dataset
from sklearn.neighbors import RadiusNeighborsClassifier

input_file = "data_banknote_authentication.txt"
data = pd.read_csv(input_file, header = 0)

array = data.values
X = array[:,0:4]
Y = array[:,4]


# In[97]:


#Impartire dataset: train + test
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.30)


# In[98]:


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)


# In[99]:


#Fit + Predict
rnc = RadiusNeighborsClassifier()
rnc.fit(X_train, Y_train)
Y_prediction = rnc.predict(X_test)

print("Y: ",Y)
print("Y_prediction:",Y_prediction)
print("Y_test:",Y_test)


# In[100]:


#5 metrici pentru clasificatorul Rneighbors cu parametri default
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score


print("Accuracy:",metrics.accuracy_score(Y_test, Y_prediction))

confusion_mat = confusion_matrix(Y_test, Y_prediction)
print("Confusion matrix is : ", confusion_mat)

recall_show = recall_score(Y_test, Y_prediction) 
print("Recall_score is :",recall_show)

precision_show = precision_score(Y_test, Y_prediction) 
print("Precision Score is : ", precision_show)

f1_score=f1_score(Y_test, Y_prediction)
print("f1 Score is : ",f1_score)


# # Eliminarea celor mai putin semnificative 2 features

# In[112]:


x = data[data.columns.drop(['Authenticity','ImgEntropy','WaveletKurt'])]
y = data['Authenticity']
x


# In[114]:


from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(x,y, test_size=0.30)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)
#Vizualizare rezultate obtinute cu parametri diferiti
range_k = range(1,30)
scores = {}
scores_list = []

for k in range_k:
   classifier = KNeighborsClassifier(n_neighbors=k)
   classifier.fit(X_train, Y_train)
   Y_prediction = classifier.predict(X_test)
   scores[k] = metrics.accuracy_score(Y_test,Y_prediction)
   scores_list.append(metrics.accuracy_score(Y_test,Y_prediction))
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt

plt.plot(range_k,scores_list)
plt.xlabel("Number of neighbors")
plt.ylabel("Accuracy after elimination features")

