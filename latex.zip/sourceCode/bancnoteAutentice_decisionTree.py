#!/usr/bin/env python
# coding: utf-8

# In[55]:


import os
import subprocess

import pandas as pd
import numpy as np
import graphviz
from sklearn.tree import DecisionTreeClassifier, export_graphviz


# In[56]:


#Incarcare dataset
input_file = "data_banknote_authentication.txt"
data = pd.read_csv(input_file, header = 0)

array = data.values
X = array[:,0:4]
Y = array[:,4]


# In[57]:


data


# In[58]:


data.shape


# In[59]:


data.columns


# In[60]:


#Primele 5 inregistrari
data.head()


# In[61]:


data.dtypes


# In[62]:


#Features
X


# In[63]:


#Target
Y


# In[64]:


#Data exploration
import seaborn
import matplotlib.pyplot as plt
  
seaborn.pairplot(data, hue ='Authenticity')
plt.show()


# In[65]:


#Data exploration
#1=nr bancnote falsificate
#0=nr bancnote autentice
data.Authenticity.value_counts().plot(kind="bar",color="blue",title="Numar de bancnote autentice/false")


# In[66]:


from sklearn import tree
model = tree.DecisionTreeClassifier()


# In[67]:


#Impartire dataset: train + test
#Fit
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.20, random_state = 0)
model.fit(X_train,Y_train)


# In[68]:


#Prezicere raspuns pentru dataset
#Predict
Y_prediction = model.predict(X_test)
print("Y: ",Y)
print("Y_prediction:",Y_prediction)
print("Y_test:",Y_test)


# In[70]:


#Testare estimator pe 2 exemple concrete
#prima inregistrare ar trebui sa aiba valoarea 0, a doua valoarea 1
my_test= [[3.6216,8.6661,-2.8073,-0.44699],[-2.5419,-0.65804,2.6842,1.1952]]
Y_prediction_test= model.predict(my_test)
print("Prediction form my given test:",Y_prediction_test)


# In[71]:


import graphviz
Z= data[data.columns.drop('Authenticity')]
dot_data = tree.export_graphviz(model, out_file = None, feature_names= Z.columns)
graph1 = graphviz.Source(dot_data)
graph1


# In[72]:


#5 metrici pentru clasificatorul initial
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score


print("Accuracy:",metrics.accuracy_score(Y_test, Y_prediction))

confusion_mat = confusion_matrix(Y_test, Y_prediction)
print("Confusion matrix is : ", confusion_mat)

recall_show = recall_score(Y_test, Y_prediction) 
print("Recall_score is :",recall_show)

precision_show = precision_score(Y_test, Y_prediction) 
print("Precision Score is : ", precision_show)

f1_score=f1_score(Y_test, Y_prediction)
print("f1 Score is : ",f1_score)


# In[73]:


from sklearn.model_selection import cross_val_score
cross_val_score(model, X_train,Y_train,cv=5)  


# In[74]:


#GridSearch pentru imbunatatire rezultate-cautarea celor mai bune valori pentru parametri
from sklearn import datasets
from sklearn.model_selection import GridSearchCV
parameters = {'criterion':('gini', 'entropy'),'splitter':('best', 'random') ,'max_depth':range(1,21),'min_samples_split':range(2,11)}
model3 = tree.DecisionTreeClassifier()
clf = GridSearchCV(model3, parameters)
clf.fit(X, Y)


# In[75]:


clf.best_params_


# In[76]:


clf.cv_results_


# # Schimbare parametrii pentru a imbunatati performanta

# In[77]:


from sklearn.metrics import f1_score
#Schimbare parametrii pentru a imbunatati performanta
#Valorile pentru parametrii sunt cei gasiti de GridSearch

clf.fit(X_train,Y_train)
Y_prediction = clf.predict(X_test)
print("Y: ",Y)
print("Y_prediction:",Y_prediction)
print("Y_test:",Y_test)
print("Metricile dupa setarea parametrilor optimi:")
print("Accuracy:",metrics.accuracy_score(Y_test, Y_prediction))

confusion_mat = confusion_matrix(Y_test, Y_prediction)
print("Confusion matrix is : ", confusion_mat)

recall_show = recall_score(Y_test, Y_prediction) 
print("Recall_score is :",recall_show)

precision_show = precision_score(Y_test, Y_prediction) 
print("Precision Score is : ", precision_show)

f1_score = f1_score(Y_test, Y_prediction)
print("f1 Score is : ",f1_score)


# In[78]:


#Cross-validation pentru modelul cu parametrii gasiti de GridSearch
from sklearn.model_selection import cross_val_score
cross_val_score(clf, X,Y,cv=2)


# # Vizualizare rezultate obtinute cu parametri diferiti

# In[79]:


#Vizualizare rezultate obtinute cu parametri diferiti
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
scores = {}
scores_list = []
#Parametrul max_depth variaza intre 1-10
maxdepth=range(1,10)

for k in maxdepth:
   classifier = tree.DecisionTreeClassifier(max_depth=k)
   classifier.fit(X_train, Y_train)
   y_pred = classifier.predict(X_test)
   scores[k] = metrics.accuracy_score(Y_test,y_pred)
   scores_list.append(metrics.accuracy_score(Y_test,y_pred))

plt.plot(maxdepth,scores_list)
plt.xlabel("Depth of the decision tree")
plt.ylabel("Accuracy")


# In[80]:


get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
scores = {}
scores_list = []
#Parametrul max_depth variaza intre 2-6
criterion=["gini","entropy"]

for k in criterion:
   classifier = tree.DecisionTreeClassifier(criterion=k)
   classifier.fit(X_train, Y_train)
   y_pred = classifier.predict(X_test)
   scores[k] = metrics.accuracy_score(Y_test,y_pred)
   scores_list.append(metrics.accuracy_score(Y_test,y_pred)) 

plt.bar(criterion,scores_list,width=0.2,color='blue')
plt.xlabel("Criterion")
plt.ylabel("Accuracy")
plt.ylim((0.97,1))
plt.show()

